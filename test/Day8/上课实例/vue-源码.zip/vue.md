### vue 基础知识
* 1. Vue起步实例
 

 1. 常用指令
 * v-if/v-show
 * v-for
 * v-bind  :style :class
 * v-model 双向绑定

 2.事件
 * @click 
 * input change 

计算属性

 3.生命周期
 * create
 * mounted
 * update
 * destroy

 4.组件
 * props 强类型 默认值
 * 组件间事件通信 $emit
 * slot 普通的  传值的

 作业
 用vue 写一个日历组件
 * 周视图
 * 当天与当前选中天区分样式
 * 上一周下一周
 * 进阶：月视图


 vue-cli
 安装vue-cli
 npm install vue-cli -g

 判断是否装好
 vue -V

 使用vue-cli创建项目
 vue init webpack myproject

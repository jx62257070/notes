<template>
  <div>
        <div class="nav">
        <div class="navLeft">
            <div class="logo">
                <a href="">校宝在线</a>
            </div>
            <div class="language"></div>
        </div>
        <div class="navRight">
            <div class="pages ">
                <div class="pageOne">我的任务</div>
            </div>
            <div class="line">|</div>
            <div class="user"></div>
        </div>
    </div>

    <div class="backGround">
        <div class="box">
            <div class="boxNav">
                <ul class="tab">
                    <li class="tab-item ">名称一好长好长好长好长好长好长好长好长好长好长好长好长</li>
                    <li class="tab-item clearfix">名称二</li>
                </ul>
            </div>
            <div class="boxInner">
                <div class="questionnaire questionnaireOne">
                    <div class="quState">
                        <p>进行中</p>
                    </div>
                    <div class="quTitle">
                        <p>标题:新高考7选3</p>
                    </div>
                    <div class="quTime">
                        <p>时间：2018-05-11 12：00 至 2018-05-18 12：00</p>
                    </div>
                    <div class="quExplain">
                        <p>这里是选课说明，很长很长的选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明明选课说明选课说明选课说明选课说明选课说明选课说明选课说明选课说明</p>
                    </div>
                    <div class="trLine"></div>
                    <div class="quBody">
                        <ul class="innerDiv">
                           <li v-for="(item, index) in json">
                             <p>Q{{item.ordNum}}、</p><p>{{item.title}}</p><p></p>
                             <ul>
                              <li v-for="(subItem, indexQu) in item.Qu">
                                <div v-if="item.type==='1'">
                                 <input type="checkbox" :name="'repeat'+index" :value="subItem.value"  v-model="item.status" @change="changeChe(subItem);ifMore(subItem,item)"><p>{{subItem.value}}</p></div>
                                <div v-else>
                                <input type="radio" :name="'repeat'+index"  :value="subItem.value" :checked="subItem.status"  @change="changeSel(subItem,item)"><p>{{subItem.value}}</p></div>
                             </li>
                             </ul>
                            

                           </li>
                        </ul>
                    </div>
                    <div>
                            <input type="button" value="提交" class="submit">
                        </div>
                </div>
                <!-- <div class="questionnaire questionnaireTwo">这是调研二</div> -->
            </div>
        </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      json :[
                {
                    ordNum:'1',
                    type:'1',
                    title:'题目名称有点长有点长有点长?',
                    num:'3',
                    max:'2',
                    min:'1',
                    status:[],
                    Qu:[{id:'1',value:'选项一',status:false},{id:'2',value:'选项二',status:false},{id:'3',value:'选项三',status:false}]
                },
                {
                    ordNum:'2',
                    type:'2',
                    title:'题目名称有点长有点长有点长?',
                    num:'3',
                    max:'1',
                    min:'1',
                    status:[],
                    Qu:[{id:'1',value:'选项一',status:false},{id:'2',value:'选项一',status:false}]
                }
            ],
      msg: 'Welcome to Your Vue.js App',
    }
  },
  methods:{
    changeSel(sub,parent){                    //单选效果

     parent.Qu.forEach((item)=>{
        if(item.id==sub.id){
          item.status = true;
        }else{
          item.status = false;
        }
     })
    },
    changeChe(subItem){                    //点击后改变复选框的checked
      subItem.status=!subItem.status;
    },
    ifMore(sub,parent){
      var ifMore=0;
      parent.Qu.forEach((item)=>{
        if(item.status==true){
          ifMore++;
        }
        console.log(ifMore);
        console.log(`max:${parent.max}`);
        
        if(ifMore>parent.max){
          this.status=false;
          alert(`最多选${parent.max}个！`)
        }
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 @import"../css/common.css";
 @import"../css/index.css";
</style>

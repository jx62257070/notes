$(function () {
    // 布局jQ
    $(".tab-item").mouseenter(function () {
        //两件事件
        $(this).addClass("active").siblings().removeClass("active");
        let idx = $(this).index();
        $(".main").eq(idx).addClass("selected").siblings().removeClass("selected");
    });

    // 布局jQ END



    //   作业一初始jQ

    //给所有的div元素添加高度属性为30px
    $(".homeworkOne div").height(30);
    //改变id为one的元素的背景颜色为红色
    $(".homeworkOne #one").css("backgroundColor", "red");
    //改变元素名为div的所有元素的背景色为#bbffaa，字体颜色为红色
    $(".homeworkOne div").css({
        color: "red",
        backgroundColor: "#bbffaa"
    });
    //改变第二个div元素的背景颜色为蓝色
    $(".homeworkOne div").eq(1).css("backgroundColor", "blue").click(function () {
        alert(1)
    })
    //匹配到标签是div或者类名存在a的元素
    console.log($(".homeworkOne div,.homeworkOne.a").length);
    //匹配标签是div中类名存在a的元素
    console.log($(".homeworkOne div.a").length);


    //   作业一初始jQ END
    // 作业一需求jQ

    $('.homeworkOneP').each(function (index, element) {
        $('.homeworkOneP').eq(index).click(() => alert($(this).text()))
    })
    // 作业一需求jQ END



    //作业二需求
    $('.homeworkTwo .TableChange tr:even').css("backgroundColor", "blue");
    //作业二需求 END




    //作业三需求
    $('.outBtn').click(() => {
        alert(`您选中了${$('input:checkbox:checked').length}个`)
    });
    //作业三需求 END



    //作业四需求
    $('.homeworkFour #submit').click(() => {
        let $ifCheck = $('input:radio:checked').length;
        if ($ifCheck === 0) {
            alert("请选择类型!");
        } else {
            let $value = $('.inputHK4').val(); // 获取值
            $value = $.trim($value); // 用jQuery的trim方法删除前后空格
            if ($value == '') { // 判断是否是空字符串，而不是null
                alert("输入不能为空!");
                return false;
            } else {
                let $checkCity = $('.city:checked').length;
                let $checkGame = $('.game:checked').length;
                let value = $('.inputHK4').val();
                if ($checkCity == 1) {
                    let exLi = $('<li></li>');
                    exLi.text(value);
                    $('#city').append(exLi);
                    $('.homeworkFour li').each(function (index, element) {
                        $('.homeworkFour li').eq(index).click(() => alert($(this).text()))
                    })
                } else {
                    if ($checkGame == 1) {
                        let exLi = $('<li></li>');
                        exLi.text(value);
                        $('#game').append(exLi);
                        $('.homeworkFour li').each(function (index, element) {
                            $('.homeworkFour li').eq(index).click(() => alert($(this).text()))
                        })
                    }
                }
            }
        }
    });
    //作业四需求 END


    //出师作业需求
    //a标签不跳转
    $('.homeworkEx a').attr("onclick", "return false");
    //delete点击事件删除节点
    $('.delete').click(function () {
        var link = $(this).parents("tr");
        link.remove();
    });
    //Edit点击事件
    $('.Edit').click(function () {
        $('.homeworkExP').html("编辑新员工");
        var $thistdName = $(this).parent().siblings().eq(0);
        var $thistdEmail = $(this).parent().siblings().eq(1);
        var $thistdSalary = $(this).parent().siblings().eq(2);
        let $tdName = $thistdName.html();
        $("#name").attr("value", $tdName);
        let $tdEmail = $thistdEmail.html();
        $("#email").attr("value", $tdEmail);
        let $tdSalary = $thistdSalary.html();
        $("#salary").attr("value", $tdSalary);
        if ($('.homeworkExP').html() == '编辑新员工') {
        $('#addEmpButton').click(() => {
            console.log($thistdName);
            
            $thistdName.val($("#name").val());
            $thistdEmail.val($("#email").val());
            $thistdSalary.val($("#salary").val());
            $('.homeworkExP').html("添加新员工");
        })}
    });
    //submit点击事件
    // $('.homeworkEx #addEmpButton').click(() => {
    //     if ($('.homeworkExP').html() == '添加新员工') {
    //         let $checkName = $('#name').val(); // 获取值   校验name
    //         $checkName = $.trim($checkName); // 用jQuery的trim方法删除前后空格
    //         if ($checkName == '') { // 判断是否是空字符串，而不是null
    //             alert("name不能为空!");
    //             return false;
    //         } else {
    //             let $checkemail = $('#email').val(); // 获取值   校验email
    //             $checkemail = $.trim($checkemail); // 用jQuery的trim方法删除前后空格
    //             if ($checkemail == '') { // 判断是否是空字符串，而不是null
    //                 alert("email不能为空!");
    //                 return false;
    //             } else {
    //                 let $checksalary = $('#salary').val(); // 获取值    校验salary
    //                 $checksalary = $.trim($checksalary); // 用jQuery的trim方法删除前后空格
    //                 if ($checksalary == '') { // 判断是否是空字符串，而不是null
    //                     alert("salary不能为空!");
    //                     return false;
    //                 } else {
    //                     //创建节点
    //                     let valueName = $('#name').val();
    //                     let valueEmail = $('#email').val();
    //                     let valueSalary = $('#salary').val();
    //                     let exTr = $(`<tr><td>${valueName}</td><td>${valueEmail}</td><td>${valueSalary}</td><td><a href="" onclick="return false" class="delete">Delete</a></td><td><a href="" onclick="return false" class="Edit">Edit</a></td></tr>`);
    //                     //为新节点添加delete点击事件
    //                     $('#employeetable').append(exTr);
    //                     $('.delete').click(function () {
    //                         var link = $(this).parents("tr");
    //                         link.remove();
    //                     });

    //                 }
    //             }
    //         }
    //     }
    // })



    //出师作业需求 END

});
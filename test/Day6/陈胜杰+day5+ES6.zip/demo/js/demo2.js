//const
const a1=1111;
console.log(`a1的值为${a1}`);
a1=22222;
console.log(`重新赋值后，a1的值为${a1}`);//TypeError: Assignment to constant variable.









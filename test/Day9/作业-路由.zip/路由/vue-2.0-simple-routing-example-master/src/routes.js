export default {
  '/': 'Home',
  '/about': 'About'
}
